﻿using System;
using System.Collections.Generic;
using System.Text;



namespace Parth_AWSServerlessApp.Models
{
    class ImageLabel
    {
        public string LabelName { get; set; }

        public float LabelConfidence { get; set; }
    }
}
